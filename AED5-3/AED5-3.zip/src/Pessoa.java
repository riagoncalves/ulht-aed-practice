public class Pessoa {
  String nome, apelido, nacionalidade;
  int nrBI;

  Pessoa(String nome, String apelido, int nrBI) {
    this.nome = nome;
    this.apelido = apelido;
    this.nrBI = nrBI;
  }

  Pessoa() {
  }
}
