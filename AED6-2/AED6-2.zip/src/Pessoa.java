public class Pessoa {
  String nome, apelido, paisMorada;
  int nrBI;

  Pessoa(String nome, String apelido, int nrBI) {
    this.nome = nome;
    this.apelido = apelido;
    this.nrBI = nrBI;
  }

  Pessoa() {
  }
}
