public class Node {
  Pessoa value;
  Node next;

  Node(){}

  Node(Pessoa value) {
    this.value = value;
  }
} 