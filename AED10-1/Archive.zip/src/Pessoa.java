public class Pessoa {
  String nome, nacionalidade;
  int bI;

  Pessoa() {}

  Pessoa(String nome, int bI, String nacionalidade) {
    this.nome = nome;
    this.bI = bI;
    this.nacionalidade = nacionalidade;
  }
}
