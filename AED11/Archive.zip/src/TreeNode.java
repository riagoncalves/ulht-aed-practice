public class TreeNode {
  Pessoa value;
  TreeNode left, right;

  TreeNode() {}

  TreeNode(Pessoa value) {
    this.value = value;
  }
}
