public class Pessoa {
  String nome;
  int nrBI;

  Pessoa(){}

  Pessoa(String nome, int nrBI) {
    this.nome = nome;
    this.nrBI = nrBI;
  }
}
