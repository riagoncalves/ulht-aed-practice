public class Arvore {
  TreeNode rootNode;

  Arvore(){}

  Arvore(TreeNode rootNode) {
    this.rootNode = rootNode;
  }
}
